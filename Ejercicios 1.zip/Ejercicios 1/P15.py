def suma_diagonalp(matriz):
    suma = 0
    for i in range(len(matriz)):
        suma += matriz[i][i]
    return suma

matriz_4x4 = [
    [2, 4, 6, 8],
    [10, 15, 20, 25],
    [5, 7, 9, 11],
    [0, 19, 29, 39]
]

suma_diagonal = suma_diagonalp(matriz_4x4)

print(f"La suma de los elementos de la diagonal principal es: {suma_diagonal}")