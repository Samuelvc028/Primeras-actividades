import struct
import csv

def copiar_a_directo(archivo_secuencial, archivo_directo):
    with open(archivo_secuencial, mode='r') as secuencial, open(archivo_directo, mode='wb') as directo:
        lector_csv = csv.reader(secuencial)

        for registro in lector_csv:

            registro_bytes = [campo.encode('utf-8') for campo in registro]
            formato = '30s50s30s10s15s3s'  # Definir el formato según la longitud de cada campo
            registro_binario = struct.pack(formato, *registro_bytes)
            directo.write(registro_binario)

archivo_secuencial_agenda = 'agenda_direcciones2.csv'
archivo_directo_agenda = 'directo_agenda2.bin'

copiar_a_directo(archivo_secuencial_agenda, archivo_directo_agenda)