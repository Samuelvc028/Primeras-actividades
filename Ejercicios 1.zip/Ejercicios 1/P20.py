def convertir_a_mayusculas(cadena):
    return cadena.upper()

def convertir_a_minusculas(cadena):
    return cadena.lower()

texto = input("Ingrese una cadena de texto: ")
texto_mayusculas = convertir_a_mayusculas(texto)
texto_minusculas = convertir_a_minusculas(texto)

print(f"Cadena en mayúsculas: {texto_mayusculas}")
print(f"Cadena en minúsculas: {texto_minusculas}")