def mcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mcd_num(num1, num2, num3, num4):
    
    resultado_temp = mcd(num1, num2)
    resultado_temp = mcd(resultado_temp, num3)
    resultado_final = mcd(resultado_temp, num4)

    return resultado_final

numero1 = int(input("Ingrese el primer número: "))
numero2 = int(input("Ingrese el segundo número: "))
numero3 = int(input("Ingrese el tercer número: "))
numero4 = int(input("Ingrese el cuarto número: "))

resultado_mcd = mcd_num(numero1, numero2, numero3, numero4)
print(f"El Máximo Común Divisor de {numero1}, {numero2}, {numero3} y {numero4} es: {resultado_mcd}")