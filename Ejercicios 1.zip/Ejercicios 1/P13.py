def contar_positivos(tabla):
    contador = 0

    for elemento in tabla:
        if elemento > 0:
            contador += 1

    return contador

tabla_numeros = [int(x) for x in input("Ingrese los números separados por espacios: ").split()]

num_positivos = contar_positivos(tabla_numeros)
print(f"El número de elementos positivos en la tabla es: {num_positivos}")