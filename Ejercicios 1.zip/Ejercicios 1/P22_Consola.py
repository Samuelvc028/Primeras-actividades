import csv

def crear_agenda():

    archivo_agenda = 'agenda_direcciones2.csv'

    with open(archivo_agenda, mode='w', newline='') as agenda:
        escritor_csv = csv.writer(agenda, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

        while True:
            nombre = input("Ingrese el nombre (o 'fin' para terminar): ")
            if nombre.lower() == 'fin':
                break

            direccion = input("Ingrese la dirección: ")
            ciudad = input("Ingrese la ciudad: ")
            codigo_postal = input("Ingrese el código postal: ")
            telefono = input("Ingrese el teléfono: ")
            edad = int(input("Ingrese la edad: "))

            escritor_csv.writerow([nombre, direccion, ciudad, codigo_postal, telefono, edad])

crear_agenda()