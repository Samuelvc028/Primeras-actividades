def encontrar_mayor(num1, num2):
    if num1 > num2:
        return num1
    else:
        return num2

numero1 = int(input("Ingrese el primer número entero: "))
numero2 = int(input("Ingrese el segundo número entero: "))

mayor = encontrar_mayor(numero1, numero2)
print(f"El número mayor entre {numero1} y {numero2} es: {mayor}")