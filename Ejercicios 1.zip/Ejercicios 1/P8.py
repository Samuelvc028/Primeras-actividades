def calcular_salario(horas_trabajadas, salario_por_hora):
    
    horas_ordinarias = min(horas_trabajadas, 40)
    horas_extra = max(horas_trabajadas - 40, 0)

    salario_ordinario = horas_ordinarias * salario_por_hora
    salario_extra = horas_extra * 1.5 * salario_por_hora

    salario_total = salario_ordinario + salario_extra

    return salario_total

horas_trabajadas = float(input("Ingrese el número de horas trabajadas: "))
salario_por_hora = float(input("Ingrese el salario por hora: "))

salario_resultante = calcular_salario(horas_trabajadas, salario_por_hora)
print(f"El salario total es: {salario_resultante}")