memo = {}

def factorial(n):
    if n < 0:
        return "Error: No se puede calcular el factorial de un número negativo"
    elif n == 0 or n == 1:
        return 1
    elif n in memo:
        return memo[n]
    else:
        result = n * factorial(n - 1)
        memo[n] = result
        return result

numero = int(input("Ingrese un número entre 100 y 1,000,000 para calcular su factorial: "))

if 100 <= numero <= 1000000:
    resultado = factorial(numero)
    print(f"El factorial de {numero} es: {resultado}")
else:
    print("Número fuera del rango especificado.")