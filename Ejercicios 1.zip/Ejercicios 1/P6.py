def fecha(dia, mes, año):

    dia_str = str(dia).zfill(2)
    mes_str = str(mes).zfill(2)
    año_str = str(año)[-2:]

    print(f"{dia_str}/{mes_str}/{año_str}")

dia = int(input("Ingrese el número de día: "))
mes = int(input("Ingrese el número de mes: "))
año = int(input("Ingrese el número de año: "))

fecha(dia, mes, año)