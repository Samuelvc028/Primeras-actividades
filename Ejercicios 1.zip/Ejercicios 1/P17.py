def calcular_myd(estudiantes):

    total_calificaciones = sum(estudiantes.values())
    media = total_calificaciones / len(estudiantes)
    print(f"Calificación media: {media}\n")

    for estudiante, calificacion in estudiantes.items():
        diferencia = calificacion - media
        print(f"{estudiante}: {calificacion}, Diferencia: {diferencia}")

nombres_estudiantes = ["Estudiante1", "Estudiante2", "Estudiante3"]
calificaciones = [85, 90, 78]
estudiantes_dict = dict(zip(nombres_estudiantes, calificaciones))

calcular_myd(estudiantes_dict)