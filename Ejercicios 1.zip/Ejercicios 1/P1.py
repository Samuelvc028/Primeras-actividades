def calcular_media():

    num1 = float(input("Ingrese el primer número: "))
    num2 = float(input("Ingrese el segundo número: "))
    num3 = float(input("Ingrese el tercer número: "))
    media = (num1 + num2 + num3) / 3
    print("La media de los tres números es:", media)

calcular_media()