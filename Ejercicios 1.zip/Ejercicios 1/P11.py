def division(dividendo, divisor):
    cociente = 0

    while dividendo >= divisor:
        dividendo -= divisor
        cociente += 1

    resto = dividendo

    print(f"División entera: {cociente}")
    print(f"Resto: {resto}")

dividendo = int(input("Ingrese el dividendo: "))
divisor = int(input("Ingrese el divisor: "))

division(dividendo, divisor)