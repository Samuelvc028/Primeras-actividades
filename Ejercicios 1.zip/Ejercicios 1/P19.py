def arabigo_romano(arabigo):
    if not 1 <= arabigo <= 3999:
        return "Número fuera del rango permitido"

    simbolos = {
        1000: 'M',
        900: 'CM',
        500: 'D',
        400: 'CD',
        100: 'C',
        90: 'XC',
        50: 'L',
        40: 'XL',
        10: 'X',
        9: 'IX',
        5: 'V',
        4: 'IV',
        1: 'I'
    }

    romano = ""
    for valor, simbolo in simbolos.items():
        while arabigo >= valor:
            romano += simbolo
            arabigo -= valor

    return romano

def romano_arabigo(romano):
    simbolos = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}

    arabigo = 0
    prev_valor = 0

    for letra in reversed(romano):
        valor = simbolos[letra]

        if valor < prev_valor:
            arabigo -= valor
        else:
            arabigo += valor

        prev_valor = valor

    return arabigo

numero_arabigo = int(input("Ingrese un número arábigoo: "))
numero_romano = input("Ingrese un número romano: ")

resultado_romano = arabigo_romano(numero_arabigo)
resultado_arabigo = romano_arabigo(numero_romano)

print(f"La representación romana de {numero_arabigo} es: {resultado_romano}")
print(f"La representación arábiga de {numero_romano} es: {resultado_arabigo}")