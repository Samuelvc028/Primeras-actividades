def matriz_identidad(n):
    matriz = [[0] * n for _ in range(n)]
    
    for i in range(n):
        matriz[i][i] = 1
    
    return matriz

matriz_resultante = matriz_identidad(4)

for fila in matriz_resultante:
    print(fila)