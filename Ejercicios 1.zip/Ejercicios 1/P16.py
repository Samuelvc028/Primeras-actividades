def encontrar_mayor(lista):
    if not lista:
        return "La lista está vacía"
    
    mayor = lista[0]

    for elemento in lista:
        if elemento > mayor:
            mayor = elemento

    return mayor

n = int(input("Ingrese la longitud de la lista: "))
lista_numeros = [float(input("Ingrese un número: ")) for i in range(n)]

mayor_valor = encontrar_mayor(lista_numeros)
print(f"El mayor valor de la lista es: {mayor_valor}")