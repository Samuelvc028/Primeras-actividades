import csv

def modificar_registro(archivo_secuencial):

    registros = []
    with open(archivo_secuencial, mode='r') as secuencial:
        lector_csv = csv.reader(secuencial)
        registros = list(lector_csv)

    print("Registros actuales:")
    for i, registro in enumerate(registros):
        print(f"{i + 1}. {registro}")

    indice_modificar = int(input("Ingrese el número del registro que desea modificar: ")) - 1

    if 0 <= indice_modificar < len(registros):
        registro_modificar = registros[indice_modificar]
        print(f"\nRegistro actual seleccionado: {registro_modificar}")

        nuevos_datos = []
        for campo in registro_modificar:
            nuevo_valor = input(f"Ingrese nuevo valor para '{campo}': ")
            nuevos_datos.append(nuevo_valor)

        registros[indice_modificar] = nuevos_datos

        with open(archivo_secuencial, mode='w', newline='') as secuencial:
            escritor_csv = csv.writer(secuencial, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            for registro in registros:
                escritor_csv.writerow(registro)

        print("Registro modificado exitosamente.")
    else:
        print("Índice fuera de rango. No se pudo modificar ningún registro.")

archivo_secuencial_agenda = 'agenda_direcciones2.csv'

modificar_registro(archivo_secuencial_agenda)