def contar_ocurrencias_palabras(texto):
    ocurrencias_a = 0
    ocurrencias_an = 0
    ocurrencias_and = 0

    for linea in texto:
        palabras = linea.split()
        ocurrencias_a += palabras.count('a')
        ocurrencias_an += palabras.count('an')
        ocurrencias_and += palabras.count('and')

    return ocurrencias_a, ocurrencias_an, ocurrencias_and

texto_ingresado = """Hola pro que más :) Ahora no se que escribir pero si escribo a deberia de aparecer uno"""

lineas = texto_ingresado.split('\n')
ocurrencias_a, ocurrencias_an, ocurrencias_and = contar_ocurrencias_palabras(lineas)

print(f"Ocurrencias de 'a': {ocurrencias_a}")
print(f"Ocurrencias de 'an': {ocurrencias_an}")
print(f"Ocurrencias de 'and': {ocurrencias_and}")