import csv

def imprimir_agenda(archivo):
    with open(archivo, mode='r') as agenda:
        lector_csv = csv.reader(agenda)
        for registro in lector_csv:
            print(registro)

archivo_agenda = 'agenda_direcciones2.csv'

imprimir_agenda(archivo_agenda)