def digito(caracter):
    return caracter.isdigit()

caracter_ingresado = input("Ingrese un carácter: ")

if digito(caracter_ingresado):
    print(f"{caracter_ingresado} es un dígito.")
else:
    print(f"{caracter_ingresado} no es un dígito.")