def fecha_valida(dia, mes, año):
    if 1 <= mes <= 12 and 1 <= dia <= 31 and 1900 <= año <= 2100:
        if (mes in [4, 6, 9, 11] and dia <= 30) or \
           (mes not in [4, 6, 9, 11] and dia <= 31):
            return True
        elif mes == 2 and ((año % 4 == 0 and año % 100 != 0) or año % 400 == 0) and dia <= 29:
            return True
    return False

dia = int(input("Ingrese el día: "))
mes = int(input("Ingrese el mes: "))
año = int(input("Ingrese el año: "))

if fecha_valida(dia, mes, año):
    print("La fecha es válida.")
else:
    print("La fecha no es válida.")