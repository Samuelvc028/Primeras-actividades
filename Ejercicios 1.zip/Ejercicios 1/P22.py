import csv

def agregar_contacto(archivo, contacto):
    with open(archivo, mode='a', newline='') as agenda:
        escritor_csv = csv.writer(agenda, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        escritor_csv.writerow(contacto)

def main():
    archivo_agenda = 'agenda_direcciones.csv'
    nuevo_contacto = ['Samuel Valencia', 'Carrera 106', 'Medellin', '12345', '3006643210', 17]
    agregar_contacto(archivo_agenda, nuevo_contacto)

if __name__ == "__main__":
    main()