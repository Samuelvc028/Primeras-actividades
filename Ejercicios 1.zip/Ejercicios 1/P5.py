def calcular_potencia(x, n):
    resultado = 1.0

    if n < 0:
        x = 1 / x
        n = -n

    for _ in range(n):
        resultado *= x

    return resultado

base = float(input("Ingrese el valor de X (variable real): "))
exponente = int(input("Ingrese el valor de n (variable entera): "))

resultado_potencia = calcular_potencia(base, exponente)
print(f"{base} elevado a la potencia {exponente} es: {resultado_potencia}")