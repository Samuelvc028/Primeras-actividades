def valor_absoluto(numero):
    return abs(numero)

numero_ingresado = float(input("Ingrese un número: "))

resultado_absoluto = valor_absoluto(numero_ingresado)
print(f"El valor absoluto de {numero_ingresado} es: {resultado_absoluto}")