import math

def cartesianas(r, theta):

    theta_radianes = math.radians(theta)
    x = r * math.cos(theta_radianes)
    y = r * math.sin(theta_radianes)

    print(f"Coordenadas cartesianas (x, y): ({x}, {y})")

radio = float(input("Ingrese el valor de r: "))
angulo = float(input("Ingrese el valor de θ en grados: "))

cartesianas(radio, angulo)