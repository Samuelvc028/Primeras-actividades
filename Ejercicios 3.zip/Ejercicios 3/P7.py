class Persona:
    def __init__(self, nombre, apellido, edad):
        self.nombre = nombre
        self.apellido = apellido
        self.edad = edad

    def obtener_nombre_completo(self):
        return f"{self.nombre} {self.apellido}"

una_persona = Persona("Samuel", "Valencia", 18)
print(f"{una_persona.obtener_nombre_completo()} tiene {una_persona.edad} años.")

# Punto 8

class Estudiante(Persona):
    def __init__(self, nombre, apellido, edad, carrera):
        super().__init__(nombre, apellido, edad)
        self.carrera = carrera

    def obtener_nombre_completo(self):
        nombre_completo = super().obtener_nombre_completo()
        return f"{nombre_completo} - Carrera: {self.carrera}"

un_estudiante = Estudiante("Sebastian", "Valencia", 18, "ADSO")
print(un_estudiante.obtener_nombre_completo())

# Punto 9

class Profesor(Persona):
    def __init__(self, nombre, apellido, edad, materia):
        super().__init__(nombre, apellido, edad)
        self.materia = materia

    def obtener_nombre_completo(self):
        nombre_completo = super().obtener_nombre_completo()
        return f"{nombre_completo} - Materia: {self.materia}"

un_profesor = Profesor("Dr. Zapata", "Espinosa", 30, "Química")
print(un_profesor.obtener_nombre_completo())