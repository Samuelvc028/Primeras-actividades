class Forma:
    def __init__(self, ancho, alto):
        self.ancho = ancho
        self.alto = alto

    def calcular_area(self):
        return self.ancho * self.alto

una_forma = Forma(6, 18)
area = una_forma.calcular_area()
print(f"El área de la forma es: {area}")

# Punto 11

class Rectangulo(Forma):
    def calcular_perimetro(self):
        return 2 * (self.ancho + self.alto)

mi_rectangulo = Rectangulo(4, 8)
area_rectangulo = mi_rectangulo.calcular_area()
perimetro_rectangulo = mi_rectangulo.calcular_perimetro()

print(f"El área del rectángulo es: {area_rectangulo}")
print(f"El perímetro del rectángulo es: {perimetro_rectangulo}")

# Punto 12

import math
class Circulo(Forma):
    def calcular_circunferencia(self):
        radio = self.ancho / 2
        return 2 * math.pi * radio

mi_circulo = Circulo(10, 4)
area_circulo = mi_circulo.calcular_area()
circunferencia_circulo = mi_circulo.calcular_circunferencia()

print(f"El área del círculo es: {area_circulo}")
print(f"La circunferencia del círculo es: {circunferencia_circulo}")