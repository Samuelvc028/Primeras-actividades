class Empleado:
    def __init__(self, nombre, apellido, sueldo):
        self.nombre = nombre
        self.apellido = apellido
        self.sueldo = sueldo

    def calcular_salario_neto(self):
        impuestos = 0.15 * self.sueldo
        salario_neto = self.sueldo - impuestos
        return salario_neto

un_empleado = Empleado("Santiago", "Valencia", 80000)
salario_neto_empleado = un_empleado.calcular_salario_neto()

print(f"El salario neto de {un_empleado.nombre} {un_empleado.apellido} es: {salario_neto_empleado}")

# Punto 14

class Gerente(Empleado):
    def __init__(self, nombre, apellido, sueldo, departamento):
        super().__init__(nombre, apellido, sueldo)
        self.departamento = departamento

    def calcular_salario_neto(self):
        impuestos = 0.25 * self.sueldo
        descuento_adicional = 0.05 * self.sueldo
        bono_gerente = 0.2 * self.sueldo
        salario_neto_gerente = self.sueldo - impuestos - descuento_adicional + bono_gerente
        return salario_neto_gerente

un_gerente = Gerente("Samara", "Valencia", 100000, "Recursos Humanos")
salario_neto_gerente = un_gerente.calcular_salario_neto()

print(f"El salario neto de {un_gerente.nombre} {un_gerente.apellido} es: {salario_neto_gerente}")

# Punto 15

class Programador(Empleado):
    def __init__(self, nombre, apellido, sueldo, lenguaje):
        super().__init__(nombre, apellido, sueldo)
        self.lenguaje = lenguaje

    def calcular_salario_neto(self):
        impuestos = 0.14 * self.sueldo
        descuento_adicional = 0.035 * self.sueldo
        bono_experto_lenguaje = 0.08 * self.sueldo
        salario_neto_programador = self.sueldo - impuestos - descuento_adicional + bono_experto_lenguaje
        return salario_neto_programador

un_programador = Programador("Samuel", "Valencia", 80000, "Python")
salario_neto_programador = un_programador.calcular_salario_neto()

print(f"El salario neto de {un_programador.nombre} {un_programador.apellido} es: {salario_neto_programador}")