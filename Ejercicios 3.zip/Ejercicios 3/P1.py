class Vehiculo:
    def __init__(self, marca, modelo, año):
        self.marca = marca
        self.modelo = modelo
        self.año = año

    def obtener_info(self):
        return f"Vehículo: {self.marca} {self.modelo} ({self.año})"

mi_auto = Vehiculo("Chevrolet", "Camaro", 1967)
print(mi_auto.obtener_info())

# Punto 2

class Automovil(Vehiculo):
    def __init__(self, marca, modelo, año, numero_puertas):
        super().__init__(marca, modelo, año)
        self.numero_puertas = numero_puertas

    def obtener_info(self):
        info_vehiculo = super().obtener_info()
        return f"{info_vehiculo} - Puertas: {self.numero_puertas}"

mi_automovil = Automovil("Ford", "Mustang", 2023, 2)
print(mi_automovil.obtener_info())

# Punto 3

class Camioneta(Vehiculo):
    def __init__(self, marca, modelo, año, capacidad_carga):
        super().__init__(marca, modelo, año)
        self.capacidad_carga = capacidad_carga

    def obtener_info(self):
        info_vehiculo = super().obtener_info()
        return f"{info_vehiculo} - Capacidad de Carga: {self.capacidad_carga} kg"

mi_camioneta = Camioneta("Toyota", "Tacoma", 2022, 1685)
print(mi_camioneta.obtener_info())