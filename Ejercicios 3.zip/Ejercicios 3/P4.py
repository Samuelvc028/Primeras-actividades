class Animal:
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    def hacer_ruido(self):
        return "Mostrar un mensaje genérico"

mi_animal = Animal("Pepe", 2)
print(f"{mi_animal.nombre} tiene {mi_animal.edad} años.")
print(mi_animal.hacer_ruido())

# Punto 5

class Perro(Animal):
    def __init__(self, nombre, edad, raza):
        super().__init__(nombre, edad)
        self.raza = raza

    def hacer_ruido(self):
        return "Guau Guau"

mi_perro = Perro("Manchas", 4, "Dálmata")
print(f"{mi_perro.nombre} es un {mi_perro.raza} de {mi_perro.edad} años.")
print(mi_perro.hacer_ruido())

# Punto 6

class Gato(Animal):
    def __init__(self, nombre, edad, pelaje):
        super().__init__(nombre, edad)
        self.pelaje = pelaje

    def hacer_ruido(self):
        return "Miau Miau"

mi_gato = Gato("Thor", 1, "Naranja")
print(f"{mi_gato.nombre} es un gato de pelaje {mi_gato.pelaje} de {mi_gato.edad} año.")
print(mi_gato.hacer_ruido())