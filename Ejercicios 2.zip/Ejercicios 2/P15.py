valores = ("Samuel", 15, "Medellin")
print(valores)