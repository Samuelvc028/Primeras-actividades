personas = {
    "Sara": 23,
    "Esteban": 31,
    "Samuel": 17,
    "Mateo": 16,
    "Juliana": 19
}
mayores = [nombre for nombre, edad in personas.items() if edad >= 18]
print(mayores)