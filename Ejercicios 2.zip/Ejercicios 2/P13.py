persona = {
    "nombre": "Samuel",
    "edad": 17,
    "ciudad": "Medellin"
}
del persona["ciudad"]
print(persona)