números = [5, 2, 8, 1, 7, 3, 9, 4, 6, 10]
ordenada = list(números)
ordenada.sort()
print(ordenada)