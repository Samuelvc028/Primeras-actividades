persona = {
    "nombre": "Samuel",
    "edad": 17,
    "ciudad": "Medellin"
}
edad = persona["edad"]
print("El elemento edad de la lista personas es:", edad)