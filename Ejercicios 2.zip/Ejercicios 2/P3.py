números = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
tercer_elemento = números[2]
print("El tercer elemento de la lista números es:", tercer_elemento)