pares = ("nombre = Samuel", "edad = 15", "ciudad = Medellin")
print(pares)