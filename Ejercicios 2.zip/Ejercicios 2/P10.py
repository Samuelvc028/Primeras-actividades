persona = {
    "nombre": "Samuel",
    "edad": 17,
    "ciudad": "Medellin"
}
print(persona)