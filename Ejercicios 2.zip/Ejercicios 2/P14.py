claves = ("nombre", "edad", "ciudad")
print(claves)