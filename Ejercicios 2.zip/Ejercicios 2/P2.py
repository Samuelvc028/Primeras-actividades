mixta = ["Hola pro qué más :)", 18, 1.74]
print(mixta)