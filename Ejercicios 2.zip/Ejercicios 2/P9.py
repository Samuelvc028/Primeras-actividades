meses = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre")
segundo_elemento = meses[1]
print("El segundo elemento de la lista meses es:", segundo_elemento)