persona = {
    "nombre": "Samuel",
    "edad": 17,
    "ciudad": "Medellin"
}
persona["edad"]=15
print(persona)